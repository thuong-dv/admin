
Upload simplepie.inc to this directory.
